package ru.wbhunter.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private LinearLayout results;
    private TextView status;
    private EditText query;
    private final int BG = Color.rgb(11,16,32), CARD = Color.rgb(20,26,44), MUTED = Color.rgb(163,176,198), WHITE = Color.WHITE;
    private final String[] ENDPOINTS = {
            "https://search.wb.ru/exactmatch/ru/common/v18/search",
            "https://search.wb.ru/exactmatch/ru/common/v13/search",
            "https://search.wb.ru/exactmatch/ru/common/v9/search"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable box(int color, int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), Color.rgb(39,50,76)); return d; }
    private TextView tv(String s, float size, int color, boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(24),dp(16),dp(28)); scroll.addView(root);
        TextView title=tv("🎯 WB Охотник",30,WHITE,true); root.addView(title);
        TextView sub=tv("Ищет аномально дешёвые предложения и показывает риск подозрительной карточки.",15,MUTED,false); sub.setPadding(0,dp(5),0,dp(18)); root.addView(sub);

        query=new EditText(this); query.setHint("Wahl Detailer, Makita или ссылка WB"); query.setHintTextColor(Color.rgb(120,135,160)); query.setTextColor(WHITE); query.setTextSize(16); query.setSingleLine(true); query.setInputType(InputType.TYPE_CLASS_TEXT); query.setPadding(dp(14),0,dp(14),0); query.setBackground(box(Color.rgb(14,20,36),12)); root.addView(query,new LinearLayout.LayoutParams(-1,dp(54)));
        Button go=new Button(this); go.setText("НАЙТИ ВЫГОДНОЕ"); go.setTextColor(WHITE); go.setTextSize(15); go.setTypeface(Typeface.DEFAULT,Typeface.BOLD); go.setBackground(box(Color.rgb(125,75,230),12)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(52)); bp.topMargin=dp(10); root.addView(go,bp);
        status=tv("Сканирование запускается только вручную.",13,MUTED,false); status.setPadding(dp(2),dp(15),dp(2),dp(12)); root.addView(status);
        results=new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); root.addView(results);
        TextView note=tv("Важно: «риск подделки» — эвристическая оценка по цене, рейтингу и количеству отзывов. Приложение не может гарантировать оригинальность товара.",12,MUTED,false); note.setPadding(dp(12),dp(16),dp(12),dp(10)); root.addView(note);
        go.setOnClickListener(v->search()); query.setOnEditorActionListener((v,a,e)->{search();return true;});
        setContentView(scroll);
    }

    private void search(){
        String q=query.getText().toString().trim(); if(q.isEmpty())return;
        Matcher m=Pattern.compile("/catalog/(\\d+)").matcher(q); if(m.find())q=m.group(1);
        final String qq=q; results.removeAllViews(); status.setText("Сканирую Wildberries…");
        executor.execute(()->{
            try { List<Item> items=fetch(qq); score(items); runOnUiThread(()->render(items)); }
            catch(Exception ex){ runOnUiThread(()->status.setText("Ошибка: "+ex.getMessage())); }
        });
    }

    private List<Item> fetch(String q) throws Exception {
        Exception last=null;
        for(String ep:ENDPOINTS){ try{
            String u=ep+"?query="+URLEncoder.encode(q,"UTF-8")+"&resultset=catalog&sort=popular&page=1&appType=1&curr=rub&dest=-1257786&spp=30";
            HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(12000); c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36"); c.setRequestProperty("Accept","application/json");
            if(c.getResponseCode()!=200) throw new Exception("WB HTTP "+c.getResponseCode());
            BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null)sb.append(line); br.close();
            JSONObject root=new JSONObject(sb.toString()); JSONObject data=root.optJSONObject("data"); JSONArray a=data!=null?data.optJSONArray("products"):root.optJSONArray("products"); if(a==null||a.length()==0) continue;
            List<Item> out=new ArrayList<>(); for(int i=0;i<a.length()&&i<40;i++){Item it=parse(a.getJSONObject(i)); if(it.price>0)out.add(it);} if(!out.isEmpty())return out;
        }catch(Exception e){last=e;} }
        throw new Exception(last==null?"Товар не найден":"Wildberries не ответил: "+last.getMessage());
    }

    private Item parse(JSONObject p){
        Item x=new Item(); x.id=p.optLong("id",p.optLong("nmId",0)); x.name=p.optString("name","Товар"); x.brand=p.optString("brand",""); x.seller=p.optString("supplier",p.optString("supplierName",""));
        double rawSale=p.optDouble("salePriceU",p.optDouble("salePrice",0)), rawOld=p.optDouble("priceU",p.optDouble("basicPriceU",0));
        if(rawSale==0){ JSONArray sizes=p.optJSONArray("sizes"); if(sizes!=null&&sizes.length()>0){JSONObject pr=sizes.optJSONObject(0).optJSONObject("price"); if(pr!=null){rawSale=pr.optDouble("product",pr.optDouble("total",0)); rawOld=pr.optDouble("basic",rawOld);}}}
        x.price=rubValue(rawSale); x.oldPrice=rubValue(rawOld); if(x.oldPrice<x.price)x.oldPrice=0; x.discount=x.oldPrice>0?Math.round((1-x.price/x.oldPrice)*1000)/10.0:0;
        x.rating=p.optDouble("reviewRating",p.optDouble("rating",0)); x.feedbacks=p.optInt("feedbacks",p.optInt("feedbacksCount",0)); return x;
    }
    private double rubValue(double v){ if(v>10000)v/=100.0; return Math.round(v*100)/100.0; }

    private void score(List<Item> xs){
        List<Double> ps=new ArrayList<>(); for(Item x:xs)if(x.price>0)ps.add(x.price); Collections.sort(ps); double med=ps.size()%2==1?ps.get(ps.size()/2):(ps.get(ps.size()/2-1)+ps.get(ps.size()/2))/2;
        for(Item x:xs){x.median=med; x.saving=med>0?Math.round((1-x.price/med)*1000)/10.0:0; int risk=0; x.reasons=new ArrayList<>();
            if(x.rating>0&&x.rating<4.3){risk+=28;x.reasons.add("низкий рейтинг");} else if(x.rating>0&&x.rating<4.6){risk+=12;x.reasons.add("рейтинг ниже желательного");}
            if(x.feedbacks<20){risk+=25;x.reasons.add("мало отзывов");} else if(x.feedbacks<100){risk+=10;x.reasons.add("небольшая история отзывов");}
            if(x.saving>55){risk+=28;x.reasons.add("цена аномально ниже медианы WB");} else if(x.saving>35){risk+=13;x.reasons.add("сильный ценовой выброс");}
            if(x.discount>75){risk+=18;x.reasons.add("очень большая заявленная скидка");} else if(x.discount>55)risk+=8; if(x.seller.isEmpty()){risk+=5;x.reasons.add("продавец не определён");}
            x.risk=Math.min(100,risk); x.deal=(int)Math.max(0,Math.min(100,Math.round(50+x.saving*.9+Math.min(x.feedbacks,1000)/100.0-x.risk*.55+Math.max(0,x.rating-4.3)*16)));
            x.verdict=x.risk>=55?"🔴 Подозрительно":(x.deal>=82&&x.saving>=20?"🔥 Суперцена":(x.deal>=67&&x.saving>=10?"🟢 Выгодно":"🟡 Обычная цена"));
        }
        xs.sort((a,b)->{int z=Integer.compare(b.deal,a.deal); return z!=0?z:Integer.compare(a.risk,b.risk);});
    }

    private String money(double v){ return NumberFormat.getIntegerInstance(new Locale("ru","RU")).format(Math.round(v))+" ₽"; }
    private void render(List<Item> xs){
        if(xs.isEmpty()){status.setText("Ничего не найдено");return;} status.setText("Найдено "+xs.size()+" предложений · медиана WB "+money(xs.get(0).median));
        for(Item x:xs){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(14),dp(14),dp(14)); c.setBackground(box(CARD,16)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(12); results.addView(c,cp);
            LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView verdict=tv(x.verdict,15,WHITE,true); top.addView(verdict,new LinearLayout.LayoutParams(0,-2,1)); TextView sc=tv("Сделка "+x.deal+"/100",12,Color.rgb(205,215,230),true); top.addView(sc); c.addView(top);
            TextView name=tv((x.brand.isEmpty()?"":x.brand+" ")+x.name,18,WHITE,true); name.setPadding(0,dp(8),0,dp(3)); c.addView(name); TextView meta=tv((x.seller.isEmpty()?"Продавец не указан":x.seller)+" · арт. "+x.id,12,MUTED,false); c.addView(meta);
            TextView price=tv(money(x.price)+(x.oldPrice>0?"   было "+money(x.oldPrice):""),25,WHITE,true); price.setPadding(0,dp(10),0,dp(8)); c.addView(price);
            TextView metrics=tv("К медиане WB: "+(x.saving>0?"−":"+")+Math.abs(x.saving)+"%    •    "+(x.rating>0?x.rating+" ★":"нет рейтинга")+" / "+x.feedbacks+" отзывов    •    риск "+x.risk+"/100",12,Color.rgb(210,218,232),false); c.addView(metrics);
            TextView rr=tv(x.reasons.isEmpty()?"✓ Явных красных флагов по выдаче нет":"⚠ "+String.join(" · ",x.reasons),12,MUTED,false); rr.setPadding(0,dp(8),0,dp(8)); c.addView(rr);
            Button open=new Button(this); open.setText("ОТКРЫТЬ НА WILDBERRIES"); open.setTextColor(WHITE); open.setBackground(box(Color.rgb(51,40,85),10)); open.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.wildberries.ru/catalog/"+x.id+"/detail.aspx")))); c.addView(open,new LinearLayout.LayoutParams(-1,dp(46)));
        }
    }

    static class Item {long id; String name="",brand="",seller="",verdict=""; double price,oldPrice,discount,rating,median,saving; int feedbacks,risk,deal; List<String> reasons;}
}
